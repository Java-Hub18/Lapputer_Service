-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2019 at 05:30 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lapputer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'info@lapputer.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `video_title` varchar(255) NOT NULL,
  `user_comment` mediumtext NOT NULL,
  `admin_reply` mediumtext NOT NULL,
  `comment_date` varchar(255) NOT NULL,
  `reply_date` varchar(255) NOT NULL,
  `valid` bit(1) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `uname`, `course_code`, `course_name`, `video_title`, `user_comment`, `admin_reply`, `comment_date`, `reply_date`, `valid`, `added_date`) VALUES
(2, 'dharmesh', 'C01', 'Basic Electronics', 'Moment JS, UTC to Local time', 'Aj is Phenomenal.', 'Yeah he is great.', '2018-06-13 00:08', '2018-06-13 00:09', b'1', '2018-06-13'),
(3, 'dharmesh', 'C02', 'CRT TV', 'Moment JS, UTC to Local time', 'okkkk', 'hmm', '2018-06-13 13:00', '2018-07-01 16:29', b'1', '2018-06-13'),
(4, 'arun', 'C01', 'Basic Electronics', 'LCD 1st', 'hi', 'yes', '2019-03-23 14:04', '2019-03-23 14:07', b'1', '2019-03-23'),
(5, 'dharmesh', 'C01', 'Basic Electronics', 'LCD 1st', 'ok', 'hmm', '2019-03-23 14:08', '2019-03-23 14:09', b'1', '2019-03-23'),
(6, 'dharmesh', 'C01', 'Basic Electronics', 'LCD 1st', 'okk', 'hmmm', '2019-03-23 14:08', '2019-03-23 14:09', b'1', '2019-03-23'),
(7, 'arun', 'C01', 'Basic Electronics', 'LCD 1st', 'iii', '', '2019-03-23 14:10', '', b'1', '2019-03-23'),
(8, 'dharmesh', 'C01', 'Basic Electronics', 'LCD 1st', 'what?', 'oo', '2019-03-23 14:10', '2019-03-23 14:11', b'1', '2019-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` mediumtext NOT NULL,
  `contact_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `contact_date`) VALUES
(1, 'Dharmesh', 'dharmeshmourya043@gmail.com', '8286847818', 'Spring Boot', 'aa', '2019-11-29 18:31:15'),
(2, 'Dharmesh', 'dharmeshmourya043@gmail.com', '8286847818', 'Spring Boot Attachment', 's', '2019-11-29 18:42:30'),
(3, 'Programming World', 'dharmeshmourya043@gmail.com', '8286847818', 'Spring Boot Attachment', 'sssssssssss', '2019-11-29 18:44:26'),
(4, 'Dharmesh', 'dharmeshmourya043@gmail.com', '8286847818', 'Spring Boot Attachment', 'wq', '2019-11-29 18:47:26'),
(5, 'Dharmesh', 'dharmeshmourya043@gmail.com', '21121212', 'Spring Boot Attachment', 'ffdfdf', '2019-11-29 18:54:42'),
(6, 'Programming World', 'dharmeshmourya043@gmail.com', '11222220', 'Spring Bootcs', 'ccc', '2019-11-29 19:04:05'),
(7, 'Programming World', 'dharmeshmourya043@gmail.com', '11222220', 'Spring Boot Attachmentsss', 'ssss', '2019-11-29 19:08:58');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(25) NOT NULL,
  `image` varchar(255) NOT NULL,
  `days` varchar(3) NOT NULL,
  `hours` varchar(3) NOT NULL,
  `fees` varchar(5) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` varchar(12) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `code`, `name`, `image`, `days`, `hours`, `fees`, `description`, `status`, `created_date`) VALUES
(1, 'C01', 'Basic Electronics', 'resources/0.jpg', '10 ', '10', '3000', 'DIP and smd components parts course design for beginners in electronics or expert in electronics . step by step understanding for parts . how to work all parts in practical session. as per theory part we know what is basic electronics but with practical work i''ll explain here how to work our theory with practical work . expert in electronics must be attend this class it''s 100% improve your knowledge . Atomic Structure,description about volt, hz,amp, resistance, watt, testing component with oscilloscope and multimeter ,how to work resistor, capacitor, diode, line filter,transistor, mosfet, transformer, built smps circuit .check and fault finding electronics parts ,digital electronics , logic gate ,ic function.', 'Active', '2019-11-24 13:50:06'),
(2, 'C02', 'CRT Tv Repairing', 'resources/x.jpg', '10 ', '10', '2000', 'Motherboard is a smart circuit it''s hard to fail. it''s observe each and every section function and when it found problem some where it will stop to work.(dead motherboard) motherboard send you signal for error . but need to understand how it work and what is the signal meaning . here i''ll explain each and every sectionwise repairing as well as fault indication theory . so attend each and every video class no any chapter is unwanted posted here. you can see each and every section repairing flow chart. this is a universal theory for any make or model motherboard .but you can find fault and repair it. my 15 year motherboard repairing experience with you in this video class. Non â?? integrated motherboard Integrated motherboard.VRM SECTION, 128 PIN INPUT OUTPUT CONTROLLER, BIOS,CLOCK CIRCUIT, RAM POWER SUPPLY,LAN, SOUND, USB, HDD,VGA,DEBUG CARD, LED ERROR,POST CODE ERROR', 'Active', '2019-11-24 13:50:10'),
(3, 'C03', 'LCD LED', 'resources\\14370209_1783347885265371_229883897460798244_n.jpg', '15 ', '15', '3000', 'laptop computer is unlike desktop computers as it is built with video chips, audio chips and processors assembled and integrated with the motherboard. These elements are not upgradeable by the user and you must look closely at the specifications for each part of the motherboard to be sure you are getting what is best for you.', 'Active', '2019-11-24 13:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `course_detail`
--

CREATE TABLE `course_detail` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `video_title` varchar(255) NOT NULL,
  `video_thumbnail` varchar(255) NOT NULL,
  `video_path` mediumtext NOT NULL,
  `days` varchar(3) NOT NULL,
  `description` mediumtext NOT NULL,
  `language` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_detail`
--

INSERT INTO `course_detail` (`id`, `name`, `code`, `video_title`, `video_thumbnail`, `video_path`, `days`, `description`, `language`, `type`, `status`, `added_date`) VALUES
(18, 'Basic Electronics', 'C01', 'LCD 1st', 'resources/1.jpg', 'https://www.youtube.com/embed/zWAiQJvwb8Q', '1', 'Laptop Volt in section is a voltage selector for Laptop motherboard . it can select voltage from DC power supply OR Battery supply .	', 'English', 'theory', 'Active', '2018-06-24'),
(19, 'Basic Electronics', 'C01', 'All about Laptop battery charging circuit...', 'resources/dharmesh1.jpg', 'https://drive.google.com/file/d/1dKDndLxifZiYnMgzo0yBCJHlrcbi4TCS/preview', '2', 'All about Laptop battery charging circuit ', 'English', 'theory', 'Active', '2018-06-24'),
(25, 'CRT Tv Repairing', 'C02', 'All about Laptop battery charging circuits...', 'resources/dharmesh1.jpg', 'https://drive.google.com/file/d/1dKDndLxifZiYnMgzo0yBCJHlrcbi4TCS/preview', '2', 'All about Laptop battery charging circuit ', 'English', 'theory', 'Active', '2018-06-24');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `title`, `description`, `status`, `added_date`) VALUES
(1, 'Bootstrap Skeleton', 'contenteditable contenteditable contenteditable contenteditable contenteditable contenteditable', 'Active', '2018-06-12');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `image`, `status`, `added_date`) VALUES
(4, 'Use of DSO', 'resources/01.jpg', 'Active', '2018-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `uname`, `course_code`, `course_name`, `status`, `added_date`) VALUES
(1, 'dharmesh', 'C01', 'Basic Electronics', 'Active', '2018-06-23'),
(2, 'arun', 'C01', 'Basic Electronics', 'Active', '2018-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` varchar(5) NOT NULL,
  `status` varchar(12) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `code`, `name`, `image`, `description`, `price`, `status`, `created_date`) VALUES
(1, 'P01', 'Hard Disk', '/uploads/prodict7.jpg', 'Hard Disk - 500 GB', '1000', '1', '2019-11-30 16:12:27'),
(2, 'P02', 'Kigston Ram', '/uploads/prodict8.jpg', 'Kigston Ram - DDR4', '3200', '1', '2019-11-30 16:17:27'),
(3, 'P03', 'Speaker', '/uploads/prodict3.jpg', 'JBL Sound', '1500', '1', '2019-11-30 16:21:19'),
(4, 'P04', 'Memory Card', '/uploads/prodict5.jpg', 'Sandisk Memory Card - 8GB', '500', '1', '2019-11-30 16:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(455) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `valid` bit(1) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `uname`, `email`, `password`, `gender`, `dob`, `age`, `country`, `state`, `city`, `address`, `phone`, `valid`, `added_date`) VALUES
(1, 'Dharmesh', 'Mourya', 'dharmesh', 'dharmeshmourya043@gmail.com', 'Dharmesh123', 'Male', '1996-01-04', 23, 'in', 'State of Maharashtra', 'Mumbai', 'Mulund', '00000000000000', b'1', '2018-06-09'),
(3, 'Arun', 'Maurya', 'arun', 'mauryaarunkumar40@gmail.com', 'Arun123', 'Male', '1996-01-10', 21, 'bd', 'Barisal Division', 'Barisal', 'yy', '132323233333', b'1', '2018-07-02'),
(4, 'Demo', 'Test', 'Test', 'mdharmesh018@gmail.com', 'Test123', 'Male', '1996-01-04', 21, 'bd', 'Chittagong', 'Bandarban', 'ddfdfd', '121323232', b'1', '2018-07-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `course_detail`
--
ALTER TABLE `course_detail`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `video_title` (`video_title`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uname` (`uname`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `course_detail`
--
ALTER TABLE `course_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
