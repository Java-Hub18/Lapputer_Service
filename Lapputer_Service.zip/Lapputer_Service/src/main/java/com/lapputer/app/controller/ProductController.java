package com.lapputer.app.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.lapputer.app.entity.Product;
import com.lapputer.app.service.ProductService;

@Controller
@RequestMapping("/shop")
public class ProductController {

	private static String uploadFolder = "/uploads";
	public static String uploadDirectory = System.getProperty("user.dir") + uploadFolder;
	private static Logger log = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService productService;

	@GetMapping(value = { "/", "/products" })
	public ModelAndView getAllProducts(Product product) {
		File file = new File(uploadDirectory);
		if (!file.exists()) {
			file.mkdir();
		}
		System.out.println("======file:====" + file);
		ModelAndView mav = new ModelAndView("shop");
		List<Product> products = productService.getAllProducts(product);
		mav.addObject("products", products);
		return mav;
	}

	@PostMapping("/saveProduct")
	public @ResponseBody ResponseEntity<?> createProduct(Product product, @RequestParam("name") final String name,
			@RequestParam("description") final String description, @RequestParam("price") final String price,
			@RequestParam("status") final String status, final @RequestParam("file") MultipartFile file) {
		try {
			System.out.println("In if...");
			HttpHeaders headers = new HttpHeaders();
			if (product == null) {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
			if (file != null && file.isEmpty()) {
				System.out.println("In if");
				// return new ResponseEntity<>("please select a file!", HttpStatus.OK);
			}
			String fileName = file.getOriginalFilename();
			String filePath = Paths.get(uploadDirectory, fileName).toString();
			log.info("filePath:: " + filePath);
			Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
			String imagePath = uploadFolder + "/" + fileName;
			// Save the file locally
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filePath)));
			stream.write(file.getBytes());
			stream.close();
			String productCode = productService.getProductCode();
			log.info("productCode:: "+productCode);
			String substr = productCode.substring(productCode.length() - 1);
			int count = Integer.parseInt(substr) + 1;
			String counter = String.valueOf(count);
			String newCode = productCode.replace(substr, counter);
			String prices[] = price.split(",");
			String names[] = name.split(",");
			String descriptions[] = description.split(",");
			String statuses[] = status.split(",");
			product.setName(names[0]);
			product.setCode(newCode);
			product.setImage(imagePath);
			product.setDescription(descriptions[0]);
			product.setPrice(prices[0]);
			product.setStatus(statuses[0]);
			product.setCreatedDate(currentTimestamp);

			boolean flag = productService.saveProduct(product);
			if (flag) {
				log.info("Product Created");
				headers.add("Product Saved With Image - ", fileName);
				return new ResponseEntity<>("Product Inserted Successfully.", headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception: " + e);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
}
