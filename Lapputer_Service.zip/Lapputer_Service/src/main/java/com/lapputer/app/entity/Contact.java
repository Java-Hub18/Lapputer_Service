package com.lapputer.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "contact")
public class Contact {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@NotNull(message = "Name can't be blank.")
	@Size(max = 50)
	@Column(name = "name", nullable = false)
	private String name;
	
	@NotNull(message = "Email can't be blank.")
	@Size(max = 50)
	@Column(name = "email", nullable = false)
	private String email;
	
	@NotNull(message = "Phone can't be blank.")
	@Size(max = 15)
	@Column(name = "phone", nullable = false)
	private String phone;
	
	@NotNull(message = "Subject can't be blank.")
	@Size(max = 50)
	@Column(name = "subject", nullable = false)
	private String subject;
	
	@NotNull(message = "Message Name can't be blank.")
	@Size(max = 1000)
	@Column(name = "message", nullable = false)
	private String message;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	@Column(name = "contact_date", nullable = false, updatable = false)
	private Timestamp contactDate;

	public Contact() {
		
	}

	public Contact(String name, String email, String phone, String subject, String message, Timestamp contactDate) {
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.subject = subject;
		this.message = message;
		this.contactDate = contactDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}
	
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Timestamp getContactDate() {
		return contactDate;
	}

	public void setContactDate(Timestamp contactDate) {
		this.contactDate = contactDate;
	}

	@Override
	public String toString() {
		return "Contact [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", subject=" + subject
				+ ", message=" + message + ", contactDate=" + contactDate + "]";
	}
	
}
