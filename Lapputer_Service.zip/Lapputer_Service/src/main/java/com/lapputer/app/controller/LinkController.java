package com.lapputer.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LinkController {
	@GetMapping(value = { "/", "/index","/home","/default"})
	public String homePage() {
		return "index";
	}
	
	@GetMapping("/contact-us")
	public String contactPage() {
		return "contact-us";
	}
	
	@GetMapping("/our-services")
	public String servicesPage() {
		return "our-services";
	}
	
	@GetMapping("/Add_Product")
	public String addProduct() {
		return "new-product";
	}
	
	@GetMapping("/about-us")
	public String aboutPage() {
		return "about-us";
	}
	
	@GetMapping("/blog")
	public String blogPage() {
		return "blog";
	}
	
	@GetMapping("/faq")
	public String faqPage() {
		return "faqs";
	}
	
	@GetMapping(value = {"/apply", "/courses/apply"})
	public String applyPage() {
		return "apply";
	}
	
	@GetMapping(value = {"/buy", "/shop/buy-product"})
	public String buyPage() {
		return "buy";
	}
}
