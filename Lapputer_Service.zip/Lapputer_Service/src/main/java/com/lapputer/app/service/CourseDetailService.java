package com.lapputer.app.service;

import java.util.List;
import com.lapputer.app.entity.CourseDetail;

public interface CourseDetailService {
	List<CourseDetail> getCourseDetailList();
	List<CourseDetail> getCourseDetailByCourseCode(String code);
}
