package com.lapputer.app;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.lapputer.app.controller.ProductController;

@SpringBootApplication
@ComponentScan("com.lapputer.app")
@EnableJpaRepositories("com.lapputer.app.repository")
@EntityScan("com.lapputer.app.entity")
//@EntityScan(basePackageClasses = {Course.class}) 
public class LapputerServiceApplication {

	public static void main(String[] args) {
		new File(ProductController.uploadDirectory).mkdir();
		SpringApplication.run(LapputerServiceApplication.class, args);
	}

}
