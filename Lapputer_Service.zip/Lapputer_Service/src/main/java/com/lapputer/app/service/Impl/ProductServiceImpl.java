package com.lapputer.app.service.Impl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lapputer.app.entity.Product;
import com.lapputer.app.repository.ProductRepository;
import com.lapputer.app.service.ProductService;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	private static String uploadFolder = "/uploads";	
	public static String uploadDirectory = System.getProperty("user.dir") + uploadFolder;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public List<Product> getAllProducts(Product product) {
		return productRepository.findAll();
	}

	@Override
	public boolean saveProduct(Product product) throws IOException {
		try {
			if (product != null) {
				productRepository.save(product);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	@Override
	public String getProductCode() {
		// TODO Auto-generated method stub
		return productRepository.findProductCode();
	}

}
