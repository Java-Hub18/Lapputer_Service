package com.lapputer.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "course_detail")
public class CourseDetail {

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Size(min = 3, max = 5)
	@Column(name = "code", nullable = false, unique = true)
	private String code;
	
	@NotNull(message = "Course Name can't be blank.")
	@Size(max = 25)
	@Column(name = "name", nullable = false, unique = true)
	private String name;
	
	@NotNull(message = "Video Title can't be blank.")
	@Size(max = 255)
	@Column(name = "video_title", nullable = false, unique = true)
	private String videoTitle;
	
	@NotNull(message = "Video Thumbnail can't be blank.")
	@Size(max = 255)
	@Column(name = "video_thumbnail", nullable = false)
	private String videoThumbnail;
	
	@NotNull(message = "Video Path can't be blank.")
	@Size(max = 255)
	@Column(name = "video_path", nullable = false)
	private String video_path;
	
	@NotNull(message = "Course Days can't be blank.")
	@Size(min = 1, max = 3)
	@Column(name = "days", nullable = false)
	private String days;
	
	@NotNull(message = "Course Description can't be blank.")
	@Size(max = 1000)
	@Column(name = "description", nullable = false)
	private String description;
	
	@NotNull(message = "Course Type can't be blank.")
	@Size(max = 12)
	@Column(name = "type", nullable = false)
	private String type;
	
	@NotNull(message = "Course Status can't be blank.")
	@Size(max = 12)
	@Column(name = "status", nullable = false)
	private String status;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	@Column(name = "created_date", nullable = false, updatable = false)
	private Timestamp createdDate;

	public CourseDetail() {}

	public CourseDetail(String code, String name, String videoTitle, String videoThumbnail, String video_path,
			String days, String description, String type, String status, Timestamp createdDate) {
			this.code = code;
			this.name = name;
			this.videoTitle = videoTitle;
			this.videoThumbnail = videoThumbnail;
			this.video_path = video_path;
			this.days = days;
			this.description = description;
			this.type = type;
			this.status = status;
			this.createdDate = createdDate;
		}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVideoTitle() {
		return videoTitle;
	}

	public void setVideoTitle(String videoTitle) {
		this.videoTitle = videoTitle;
	}

	public String getVideoThumbnail() {
		return videoThumbnail;
	}

	public void setVideoThumbnail(String videoThumbnail) {
		this.videoThumbnail = videoThumbnail;
	}

	public String getVideo_path() {
		return video_path;
	}

	public void setVideo_path(String video_path) {
		this.video_path = video_path;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "CourseDetail [id=" + id + ", code=" + code + ", name=" + name + ", videoTitle=" + videoTitle
				+ ", videoThumbnail=" + videoThumbnail + ", video_path=" + video_path + ", days=" + days
				+ ", description=" + description + ", type=" + type + ", status=" + status + ", createdDate="
				+ createdDate + "]";
	}
}
