package com.lapputer.app.controller;

import java.sql.Timestamp;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.lapputer.app.entity.Contact;
import com.lapputer.app.service.ContactService;

@Controller
public class ContactController {

	private static Logger log = LoggerFactory.getLogger(ContactController.class);
	
	@Autowired
	ContactService contactService;
	
	@PostMapping("/saveContact")
	//@GetMapping("/saveContact")
	public @ResponseBody ResponseEntity<?> createContact(@Valid Contact contact,
			@RequestParam("name") final String name, @RequestParam("email") final String email,
			@RequestParam("phone") final String phone, @RequestParam("subject") final String subject,
			@RequestParam("message") final String message) {
		try {
			System.out.println("=============================================");
			HttpHeaders headers = new HttpHeaders();
			if (contact == null) {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
			//String[] desg = designation.split(",");
			
			Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

			log.info("Name: " + name);
			//log.info("Designation: " + desg[0]);
			log.info("Email: " + email);
			log.info("Phone: " + phone);
			log.info("Subject: " + subject);
			log.info("message: " + message);

			contact.setName(name);
			contact.setEmail(email);
			contact.setPhone(phone);
			contact.setSubject(subject);
			contact.setMessage(message);
			contact.setContactDate(currentTimestamp);

			boolean status = contactService.saveContacts(contact);
			if (status) {
				log.info("Contact Saved.");
				headers.add("User Saved With name - ", name);
				return new ResponseEntity<>("Thank you " + name +", for contacting us We will revert you soon. ", headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception: " + e);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
}
