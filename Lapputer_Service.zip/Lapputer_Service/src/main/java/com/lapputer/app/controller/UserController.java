package com.lapputer.app.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.lapputer.app.entity.Product;
import com.lapputer.app.entity.User;
import com.lapputer.app.repository.ProductRepository;
import com.lapputer.app.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	private final Logger log = LoggerFactory.getLogger(this.getClass());
	// @InitBinder - pre process every string data.
	// removes the leading & trailing white spaces.
	// If string only has white space .... trim it to null.

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		StringTrimmerEditor ste = new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class, ste);
	}

	// Inject EmployeeService to call it's methods
	@Autowired
	private UserService userService;

	@Autowired
	private ProductRepository productRepository;
	
	@GetMapping("/sign-up")
	public ModelAndView userSignUpPage(User user) {
		return new ModelAndView("sign-up", "sign-up", user);
	}

	@GetMapping("/sign-in")
	public ModelAndView userSignInPage(User user) {
		return new ModelAndView("sign-in", "sign-in", user);
	}

	@GetMapping("/home")
	public ModelAndView userHomePage(User user, RedirectAttributes redirectAttributes) {
		List<Product> topProducts = productRepository.findTopProducts();
		redirectAttributes.addFlashAttribute("topProducts", topProducts);
		return new ModelAndView("home", "topProducts", topProducts);
	}
	
	@GetMapping("/logout")
	public ModelAndView userLogoutPage(User user, HttpSession session, HttpServletRequest request, HttpServletResponse response) {
		session = request.getSession();
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
        response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
        response.setDateHeader("Expires", 0); // Proxies.
        session.invalidate();
		return new ModelAndView("logout");
	}
	
	@PostMapping("/saveUser")
	public ModelAndView createUser(@Valid @ModelAttribute("sign-up") User user, BindingResult br,
			HttpServletRequest request, HttpSession session) {
		try {
			if(!br.hasErrors()) {
				log.info("in if saving user...");
				userService.saveUser(user);
				log.info("user saved with id..."+user.getId());
				session = request.getSession(false);
				String userName = user.getFirstName().substring(0, 1).toUpperCase() + user.getLastName().substring(0, 1).toUpperCase();
				session.setAttribute("userName", userName);
				return new ModelAndView("redirect:/user/home");
			} else {
				log.info("in else br");
				return new ModelAndView("sign-up");
			}
		} catch (Exception e) {
			log.debug("in catch "+e);
			return new ModelAndView("sign-up");
		}
	}

	@PostMapping("/validateUser")
	public ModelAndView checkUserUser(@Valid @ModelAttribute("sign-in") User user, BindingResult br,
			RedirectAttributes redirectAttributes, HttpSession session, HttpServletRequest request) {
		try {
//				if(br.hasErrors()) {
//					log.error("Please fill all the required fields.");
//					return new ModelAndView("sign-in");
//				} else {
				// Check if user exists
				log.info("Checking User Existence.");
				User userExist = userService.findUserByEmail(user.getEmail());
				if (userExist != null) {
					log.info("User Exist True.");
					User status = userService.findUser(user.getEmail(), user.getPassword());
					if (status != null) {
						log.info("in status");
						session = request.getSession(false);
						String userName = status.getFirstName().substring(0, 1).toUpperCase() + status.getLastName().substring(0, 1).toUpperCase();
						session.setAttribute("userName", userName);
						return new ModelAndView("redirect:/user/home");
					} else {
						log.info("in status else");
						br.rejectValue("password", "error.user", "Password doesn't match.");
					}
				} else {
					log.info("User Exist False.");
					br.rejectValue("email", "error.user", "Could not find a user with this email.");
				}
			//}	
		} catch (Exception e) {
			log.error("in catch "+e);
			return new ModelAndView("sign-in");
		}
		return new ModelAndView("sign-in");
	}
}
