package com.lapputer.app.service.Impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.lapputer.app.entity.User;
import com.lapputer.app.repository.UserRepository;
import com.lapputer.app.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public void saveUser(User user) {
		try {
			if (user != null) {
				userRepository.save(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public User findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public String findUserPassword(String email) {
		return userRepository.findUserPassword(email);
	}

	@Override
	public Optional<User> findUserById(Long id) {
		return userRepository.findById(id);
	}

	@Override
	public User findUser(String email, String password) {
		return userRepository.checkUser(email, password);
	}

}
