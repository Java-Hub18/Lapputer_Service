package com.lapputer.app.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.lapputer.app.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	@Query(value = "select u from User u where u.email like ?1")
	public User findByEmail(String email);
	
	@Query(value = "select u.password from User u where u.email like ?1")
	public String findUserPassword(String email); 
	
	@Query(value = "select u from User u where u.id like ?1")
	public Optional<User> findById(Long id);
	
	@Query(value = "select u from User u where u.email like ?1 and u.password like ?2")
	public User checkUser(String email, String password);
}
