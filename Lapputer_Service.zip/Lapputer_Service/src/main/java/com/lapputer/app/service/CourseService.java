package com.lapputer.app.service;

import java.util.List;

import com.lapputer.app.entity.Course;

public interface CourseService {
	
	List<Course> getAllCourses();
	
	Course getCourseByCourseCode(String code);
	String getCourseNameByCourseCode(String code);
}
