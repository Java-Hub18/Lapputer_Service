package com.lapputer.app.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "course")
public class Course {

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Size(min = 3, max = 5)
	@Column(name = "code", nullable = false, unique = true)
	private String code;
	
	@NotNull(message = "Course Name can't be blank.")
	@Size(max = 25)
	@Column(name = "name", nullable = false, unique = true)
	private String name;
	
	@NotNull(message = "Course Image can't be blank.")
	@Size(max = 255)
	@Column(name = "image", nullable = false)
	private String image;
	
	@NotNull(message = "Course Days can't be blank.")
	@Size(min = 2, max = 3)
	@Column(name = "days", nullable = false)
	private String days;
	
	@NotNull(message = "Course Hours can't be blank.")
	@Size(min = 1, max = 3)
	@Column(name = "hours", nullable = false)
	private String hours;
	
	@NotNull(message = "Course Fees can't be blank.")
	@Size(min = 3, max = 5)
	@Column(name = "fees", nullable = false)
	private String fees;
	
	@NotNull(message = "Course Description can't be blank.")
	@Size(max = 1000)
	@Column(name = "description", nullable = false)
	private String description;
	
	@NotNull(message = "Course Status can't be blank.")
	@Size(max = 12)
	@Column(name = "status", nullable = false)
	private String status;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	@Column(name = "created_date", nullable = false, updatable = false)
	private Timestamp createdDate;

	public Course() {
		
	}

	public Course(String code, String name, String image, String days, String hours, String fees,
			String description, String status, Timestamp createdDate) {
		this.code = code;
		this.name = name;
		this.image = image;
		this.days = days;
		this.hours = hours;
		this.fees = fees;
		this.description = description;
		this.status = status;
		this.createdDate = createdDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}

	public String getFees() {
		return fees;
	}

	public void setFees(String fees) {
		this.fees = fees;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", code=" + code + ", name=" + name + ", image=" + image + ", days=" + days
				+ ", hours=" + hours + ", fees=" + fees + ", description=" + description + ", status=" + status
				+ ", createdDate=" + createdDate + "]";
	}
	
	
	
}
