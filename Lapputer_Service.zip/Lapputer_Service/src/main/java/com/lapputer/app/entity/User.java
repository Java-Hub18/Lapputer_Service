package com.lapputer.app.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "user")
public class User {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false, unique = true)
	private Long id;
	
	@NotNull(message = "User FirstName can't be blank.")
	@Size(min = 2, max = 50, message = "FirstName must be between 2 and 50 characters.")
	@Column(name = "firstname", nullable = false)
	private String firstName;
	
	@NotNull(message = "User LastName can't be blank.")
	@Size(min = 2, max = 50, message = "LastName must be between 2 and 50 characters.")
	@Column(name = "lastname", nullable = false)
	private String lastName;
	
	@NotNull(message = "User Email can't be blank.")
	@Size(min = 11, max = 100, message = "Email must be between 11 and 100 characters.")
	@Column(name = "email", nullable = false, unique = true)
	private String email;
	
	@NotNull(message = "User Password can't be blank.")
	@Size(min = 5, max = 60, message = "Password must be between 5 and 60 characters.")
	@Column(name = "password", nullable = false)
	private String password;
	
	@NotNull(message = "Phone Number can't be blank.")
	@Size(max = 10, message = "Phone Number must be of 10 digits only.")
	@Column(name = "phone", nullable = false, unique = true)
	private String phone;
	
	@NotNull(message = "Gender can't be blank.")
	@Size(min = 4, max = 6, message = "Gender must be either male or female.")
	@Column(name = "gender", nullable = false)
	private String gender;
	
	@NotNull(message = "User DOB can't be blank.")
	@Past(message = "Please Select Past Date.")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name = "dob", nullable = false)
	private LocalDate dob;
	
	@NotNull(message = "Country Name can't be blank.")
	@Size(min = 2, max = 20, message = "Country Name must be between 2 and 20 characters.")
	@Column(name = "country", nullable = false)
	private String country;
	
	@NotNull(message = "State Name can't be blank.")
	@Size(min = 2, max = 20, message = "State Name must be between 2 and 20 characters.")
	@Column(name = "state", nullable = false)
	private String state;
	
	@NotNull(message = "City Name can't be blank.")
	@Size(min = 2, max = 20, message = "City Name must be between 2 and 20 characters.")
	@Column(name = "city", nullable = false)
	private String city;
	
	public User() {}
	
	public User(String firstName, String lastName, String email, String password, String phone, String gender,
			LocalDate dob, String country, String state, String city) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.phone = phone;
		this.gender = gender;
		this.dob = dob;
		this.country = country;
		this.state = state;
		this.city = city;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", password=" + password + ", phone=" + phone + ", gender=" + gender + ", dob=" + dob + ", country="
				+ country + ", state=" + state + ", city=" + city + "]";
	}
}
