package com.lapputer.app.service.Impl;

import java.util.List;
import javax.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lapputer.app.entity.Contact;
import com.lapputer.app.repository.ContactRepository;
import com.lapputer.app.service.ContactService;

@Service
@Transactional
public class ContactServiceImpl implements ContactService {

	@Autowired
	private ContactRepository contactRepository;

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private Environment env; // to get values from property file.

	@Override
	public boolean saveContacts(Contact contact) {
		boolean status = false;
		try {
			if (contact != null) {
				status = true;
				MimeMessage message = emailSender.createMimeMessage();
				// use the true flag to indicate you need a multipart message
				MimeMessageHelper helper = new MimeMessageHelper(message, true);
				String content = "Hi, <b>" + contact.getName()
						+ "</b> has contacted you. Below are the details of his/her message.<br>";
				helper.setSubject(contact.getSubject());
				helper.setText(content + " <b>Name: </b> " + contact.getName() + "<br>" + "" + "<b>Email: </b> "
						+ contact.getEmail() + "<br>" + "<b>Phone: </b> " + contact.getPhone() + "<br>"
						+ "<b>Subject: </b> " + contact.getSubject() + "<br>" + "<b>Message:</b> "
						+ contact.getMessage(), true); // set to html
				helper.setFrom(contact.getEmail());
				helper.setTo(env.getProperty("spring.mail.username"));
				helper.addCc(env.getProperty("mailToCc"));

				emailSender.send(message);
				contactRepository.save(contact);
			}
		} catch (Exception e) {
			status = false;
			System.out.println(e.getMessage());
		}
		return status;
	}

	@Override
	public List<Contact> getAllContacts() {
		return contactRepository.findAll();
	}

}
