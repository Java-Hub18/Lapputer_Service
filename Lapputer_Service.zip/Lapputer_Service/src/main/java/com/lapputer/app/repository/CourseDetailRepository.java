package com.lapputer.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lapputer.app.entity.CourseDetail;

public interface CourseDetailRepository extends JpaRepository<CourseDetail, Long>{

	@Query(value = "select cd from CourseDetail cd where cd.code like ?1")
	public List<CourseDetail> findCourseDetailByCourseCode(String code);
}
