package com.lapputer.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "product")
public class Product {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Size(min = 3, max = 5)
	@Column(name = "code", nullable = false, unique = true)
	private String code;
	
	@NotNull(message = "Product Name can't be blank.")
	@Size(max = 100)
	@Column(name = "name", nullable = false, unique = true)
	private String name;
	
	@NotNull(message = "Product Image can't be blank.")
	@Size(max = 255)
	@Column(name = "image", nullable = false)
	private String image;
	
	@NotNull(message = "Product Description can't be blank.")
	@Size(max = 1000)
	@Column(name = "description", nullable = false)
	private String description;
	
	@Size(min = 3, max = 15)
	@Column(name = "price", nullable = false)
	private String price;
	
	@NotNull(message = "Product Status can't be blank.")
	@Size(max = 12)
	@Column(name = "status", nullable = false)
	private String status;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	@Column(name = "created_date", nullable = false, updatable = false)
	private Timestamp createdDate;
	
	public Product() {

	}

	public Product(String code, String name, String image, String description, String price, String status,
			Timestamp createdDate) {
		this.code = code;
		this.name = name;
		this.image = image;
		this.description = description;
		this.price = price;
		this.status = status;
		this.createdDate = createdDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	
}
