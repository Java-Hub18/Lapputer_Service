package com.lapputer.app.service;

import java.io.IOException;
import java.util.List;

import com.lapputer.app.entity.Product;

public interface ProductService {
	
	boolean saveProduct(Product product) throws IOException;
	List<Product> getAllProducts(Product product);
	String getProductCode();
	
}
