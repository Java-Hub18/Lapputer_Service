package com.lapputer.app.service;

import java.util.Optional;

import com.lapputer.app.entity.User;

public interface UserService {

	void saveUser(User user);
	
	User findUserByEmail(String email);
	
	String findUserPassword(String email);
	
	Optional<User> findUserById(Long id);
	
	User findUser(String email, String password);
}
