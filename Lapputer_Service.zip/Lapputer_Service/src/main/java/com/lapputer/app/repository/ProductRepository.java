package com.lapputer.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lapputer.app.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

	
	@Query(nativeQuery = true, value = "select code from Product order by id desc limit 1")
	public String findProductCode();
	
	@Query(nativeQuery = true, value = "select * from Product order by id asc limit 4")
	public List<Product> findTopProducts();
}
