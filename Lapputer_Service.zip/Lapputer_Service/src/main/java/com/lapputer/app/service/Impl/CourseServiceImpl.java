package com.lapputer.app.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lapputer.app.entity.Course;
import com.lapputer.app.repository.CourseRepository;
import com.lapputer.app.service.CourseService;

@Service
@Transactional
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;

	@Override
	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	@Override
	public Course getCourseByCourseCode(String code) {
		return courseRepository.findCourseByCourseCode(code);
	}

	@Override
	public String getCourseNameByCourseCode(String code) {
		System.out.println("in serviceimpl ::"+code);
		return courseRepository.findCourseNameByCourseCode(code);
	}
	
	
}
