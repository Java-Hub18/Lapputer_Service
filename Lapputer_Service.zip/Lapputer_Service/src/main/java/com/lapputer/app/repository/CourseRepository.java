package com.lapputer.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lapputer.app.entity.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {
	
	@Query(value = "select c from Course c where c.name like ?1")
	Course findCourseByCourseCode(String code);
	
	@Query(value = "select c.name from Course c where c.code like ?1")
	String findCourseNameByCourseCode(String code);

}
