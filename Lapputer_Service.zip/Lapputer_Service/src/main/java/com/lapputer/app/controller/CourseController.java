package com.lapputer.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lapputer.app.entity.Course;
import com.lapputer.app.service.CourseService;

@Controller
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	@GetMapping("/courses")
	ModelAndView listAllCourses(Course course) {
		ModelAndView mav = new ModelAndView("courses");
		List<Course> courses = courseService.getAllCourses();
		mav.addObject("courses", courses);
		return mav;
	}
}
