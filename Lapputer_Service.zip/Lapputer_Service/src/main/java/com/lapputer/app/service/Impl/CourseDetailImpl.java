package com.lapputer.app.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lapputer.app.entity.CourseDetail;
import com.lapputer.app.repository.CourseDetailRepository;
import com.lapputer.app.service.CourseDetailService;

@Service
@Transactional
public class CourseDetailImpl implements CourseDetailService {

	@Autowired
	private CourseDetailRepository courseDetailRepository;
	
	@Override
	public List<CourseDetail> getCourseDetailList() {
		return courseDetailRepository.findAll();
	}

	@Override
	public List<CourseDetail> getCourseDetailByCourseCode(String code) {
		return courseDetailRepository.findCourseDetailByCourseCode(code);
	}

}
