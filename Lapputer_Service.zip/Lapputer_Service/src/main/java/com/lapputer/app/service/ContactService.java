package com.lapputer.app.service;

import java.util.List;

import com.lapputer.app.entity.Contact;

public interface ContactService {
	boolean saveContacts(Contact contact);

	List<Contact> getAllContacts();
}
