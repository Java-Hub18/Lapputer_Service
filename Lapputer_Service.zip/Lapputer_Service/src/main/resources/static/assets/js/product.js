   	$(document).ready(function () {
    // bind form submit event
   		$('#loader').hide();
    $("#form").on("submit", function (e) {
        // cancel the default behavior
        e.preventDefault();
    	var name = $("#name").val();
        var file = $("#file").val(); 
        var status = $("#status").val();
        var price = $("#price").val();
        var description = $("#description").val();
    	var data = new FormData($("#form")[0]);
    	data.append('name', name);
    	data.append('status', status);
    	data.append('price', price);
    	data.append('description', description);
    	data.append('file', file);  
        $('#loader').show();
        if (name === "" || file === "" || status === "" || price === "" || description === "") {
        	$("#submit").prop("disabled", false);
            $('#loader').hide();
            $("#name").css("border-color", "red");
            $("#file").css("border-color", "red");
            $("#status").css("border-color", "red");
            $("#price").css("border-color", "red");
            $("#description").css("border-color", "red");
            $("#error_name").html("Please fill the required field.");
            $("#error_file").html("Please fill the required field.");
            $("#error_status").html("Please fill the required field.");
            $("#error_price").html("Please fill the required field.");
            $("#error_description").html("Please fill the required field.");
        } else {
            $("#name").css("border-color", "");
            $("#file").css("border-color", "");
            $("#status").css("border-color", "");
            $("#price").css("border-color", "");
            $("#description").css("border-color", "");
            $('#error_name').css('opacity', 0);
            $('#error_file').css('opacity', 0);
            $('#error_status').css('opacity', 0);
            $('#error_price').css('opacity', 0);
            $('#error_description').css('opacity', 0);
                    $.ajax({
                        type: 'POST',
                        enctype: 'multipart/form-data',
                        data: data,
                        url: "/shop/saveProduct", 
                        processData: false,
                        contentType: false,
                        cache: false, 
                        success: function(data, statusText, xhr) {
                        console.log(xhr.status);
                        if(xhr.status == "200") {
                        	$('#loader').hide(); 
                            $("#form")[0].reset();
                            $("#error").text("");
                            $("#success").text(data);
                            $('#success').delay(5000).fadeOut('slow');
                         }	   
                        },
                        error: function(e){
                        	$('#loader').hide();
                            $("#error").text(e.responseText);
                            $('#error').delay(10000).fadeOut('slow');
                        }
                    });
        }
            });
        });