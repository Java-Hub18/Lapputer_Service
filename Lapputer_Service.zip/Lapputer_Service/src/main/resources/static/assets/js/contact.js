   	$(document).ready(function() {
            $('#loader').hide();
            $("#submit").on("click", function() {
            	//alert("clicked");
            $("#submit").prop("disabled", true);
                var name = $("#name").val();
                var email = $("#email").val();
                var subject = $("#subject").val();
                var message = $("#message").val();
                var phone = $("#phone").val();
                var formData = $("#form").serialize();
                $('#loader').show();
                if (name === "" || email === "" || message === "" || phone === "" || subject === "") {
                	$("#submit").prop("disabled", false);
                    $('#loader').hide();
                    $("#name").css("border-color", "red");
                    $("#email").css("border-color", "red");
                    $("#phone").css("border-color", "red");
                    $("#subject").css("border-color", "red");
                    $("#message").css("border-color", "red");
                    $("#error_name").html("Please fill the required field.");
                    $("#error_email").html("Please fill the required field.");
                    $("#error_phone").html("Please fill the required field.");
                    $("#error_subject").html("Please fill the required field.");
                    $("#error_message").html("Please fill the required field.");
                } else {
                    $("#name").css("border-color", "");
                    $("#email").css("border-color", "");
                    $("#phone").css("border-color", "");
                    $("#message").css("border-color", "");
                    $("#subject").css("border-color", "");
                    $('#error_name').css('opacity', 0);
                    $('#error_email').css('opacity', 0);
                    $('#error_phone').css('opacity', 0);
                    $('#error_subject').css('opacity', 0);
                    $('#error_message').css('opacity', 0);
                    $.ajax({
                        type: 'POST',
                        data: formData,
                        url: "saveContact", 
                        success: function(data, statusText, xhr) {
                        console.log(xhr.status);
                        if(xhr.status == "200") {
                        	$('#loader').hide(); 
                            $("#form")[0].reset();
                            $("#error").text("");
                            $("#success").text(data);
                            $('#success').delay(5000).fadeOut('slow');
                            $("#submit").prop("disabled", false);
                         }	   
                        },
                        error: function(e){
                        	$('#loader').hide();
                            $("#error").text(e.responseText);
                            $('#error').delay(10000).fadeOut('slow');
                            $("#submit").prop("disabled", false);
                        }
                    });
                }
            });
        });