package com.lapputer.electronics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LapputerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
